Currency-Converter
==================

Currency Converter written in Javascript using jQuery and the Open Source Exchange Rates API