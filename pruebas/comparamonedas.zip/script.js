 window.addEventListener('load', function(e) {
  mymuestra();
}, false);

    
//hace comparacion - - - - - - - - - - - - - - - - - - - -
function myresta(a, b){
 resta = a-b;
 return resta;
}


//evalua - - - - - - - - - - - - - - - - - - - 
function myevaluacion(a, b){
 var mensaje;
 if (a<b){ mensaje= "chico";}
 else { mensaje = "grande"; }
 return mensaje;
}


//variables y funciones - - - - - - - - - - - - - - - - - - - 
resultadosuma = myresta(4, 9);
valorreferencia = 11;
resultadoevaluacion = myevaluacion(resultadosuma,valorreferencia);


//muestra en html - - - - - - - - - - - - - - - - - - - 
function mymuestra(){
 document.querySelector('#test').innerHTML = 
  '<span class="dest"> la suma es; </span>' + resultadosuma + "</br>" + 
  '<span class="dest"> comparacion mas </span>' +resultadoevaluacion +"<br>"+ 
  " que " + valorreferencia;
}